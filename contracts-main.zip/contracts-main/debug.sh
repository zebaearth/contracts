#!/usr/bin/env sh

cd test-blockchain
bash clean.sh
bash start.sh
