#!/usr/bin/env sh

CWD=$PWD

# pkill -f geth

sudo rm -rf $CWD/data
