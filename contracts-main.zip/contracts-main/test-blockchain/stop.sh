#!/usr/bin/env sh

CWD=$PWD

pkill -f geth
