npm run truffle:compile
npm run truffle:migrate:dev -- --reset --to 4
npm run truffle:migrate:dev:bor -- --reset -f 5 --to 5
npm run truffle:migrate:dev -- -f 6 --to 6
